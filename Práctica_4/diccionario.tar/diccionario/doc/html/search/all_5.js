var searchData=
[
  ['filtraporintervalo',['FiltraPorIntervalo',['../classDiccionario.html#a0b6e19ef8a378f77d9411e4a873a1d76',1,'Diccionario']]],
  ['filtraporpalabraclave',['FiltraPorPalabraClave',['../classDiccionario.html#a20b621eb60d2e7dda2175b543484f6b2',1,'Diccionario']]]
];
