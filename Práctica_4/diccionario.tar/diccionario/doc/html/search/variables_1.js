var searchData=
[
  ['termino',['termino',['../classTermino.html#a5656fe283f6e949ec67d6231f7154a3d',1,'Termino']]]
];
