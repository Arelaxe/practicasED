var searchData=
[
  ['termino',['Termino',['../classTermino.html',1,'Termino'],['../classTermino.html#ac3b1425fec4d38d78c5d36cb5fe8e728',1,'Termino::Termino()'],['../classTermino.html#a9ec8e65752439d7f58be1a7ee7334e0b',1,'Termino::Termino(string palabra, vector&lt; string &gt; defs)'],['../classTermino.html#a5614ae8912f6aabd677762cc6d10f2c8',1,'Termino::Termino(const Termino &amp;otro)'],['../classTermino.html#a5656fe283f6e949ec67d6231f7154a3d',1,'Termino::termino()']]],
  ['termino_2eh',['Termino.h',['../Termino_8h.html',1,'']]]
];
