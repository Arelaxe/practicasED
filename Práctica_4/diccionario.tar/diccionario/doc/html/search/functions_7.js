var searchData=
[
  ['recuentodefiniciones',['RecuentoDefiniciones',['../classDiccionario.html#a3f5e319cf231c4156fdf071e529b2142',1,'Diccionario']]]
];
