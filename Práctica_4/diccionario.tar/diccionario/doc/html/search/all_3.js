var searchData=
[
  ['diccionario',['Diccionario',['../classDiccionario.html',1,'Diccionario'],['../classDiccionario.html#a2715031923b30792221622bfa773189c',1,'Diccionario::diccionario()'],['../classDiccionario.html#aa0a2191ec706b256c35b5229cc197b15',1,'Diccionario::Diccionario()'],['../classDiccionario.html#a38334390fc9b673fb674f7e712c65657',1,'Diccionario::Diccionario(set&lt; Termino &gt; terminos)'],['../classDiccionario.html#a5f79e840a08666f29b527eb78be167e0',1,'Diccionario::Diccionario(const Diccionario &amp;otro)']]],
  ['diccionario_2eh',['Diccionario.h',['../Diccionario_8h.html',1,'']]]
];
