var searchData=
[
  ['diccionario',['diccionario',['../classDiccionario.html#a2715031923b30792221622bfa773189c',1,'Diccionario']]]
];
