var searchData=
[
  ['diccionario',['Diccionario',['../classDiccionario.html#aa0a2191ec706b256c35b5229cc197b15',1,'Diccionario::Diccionario()'],['../classDiccionario.html#a38334390fc9b673fb674f7e712c65657',1,'Diccionario::Diccionario(set&lt; Termino &gt; terminos)'],['../classDiccionario.html#a5f79e840a08666f29b527eb78be167e0',1,'Diccionario::Diccionario(const Diccionario &amp;otro)']]]
];
