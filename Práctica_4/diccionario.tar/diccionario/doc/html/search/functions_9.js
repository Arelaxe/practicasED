var searchData=
[
  ['termino',['Termino',['../classTermino.html#ac3b1425fec4d38d78c5d36cb5fe8e728',1,'Termino::Termino()'],['../classTermino.html#a9ec8e65752439d7f58be1a7ee7334e0b',1,'Termino::Termino(string palabra, vector&lt; string &gt; defs)'],['../classTermino.html#a5614ae8912f6aabd677762cc6d10f2c8',1,'Termino::Termino(const Termino &amp;otro)']]]
];
