var searchData=
[
  ['const_5fiterator',['const_iterator',['../classTermino.html#a0c8a38779eb1a65b8fe9422b430895c9',1,'Termino::const_iterator()'],['../classDiccionario.html#a2e86a5840e62eab4f1499c2f23561cba',1,'Diccionario::const_iterator()']]]
];
