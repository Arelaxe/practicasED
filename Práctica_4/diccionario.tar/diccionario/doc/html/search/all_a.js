var searchData=
[
  ['setdefiniciones',['SetDefiniciones',['../classTermino.html#a2345118df3073c53c0722abb4b091da0',1,'Termino']]],
  ['setpalabra',['SetPalabra',['../classTermino.html#a6d148c1d2aaaa5ebc40fc1eb6e34857a',1,'Termino']]]
];
