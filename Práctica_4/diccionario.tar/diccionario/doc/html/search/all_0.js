var searchData=
[
  ['aniadedefinicion',['AniadeDefinicion',['../classTermino.html#a93fed012290bc28881288cfd095c8500',1,'Termino']]],
  ['aniadetermino',['AniadeTermino',['../classDiccionario.html#a95512d5b0735da4a1dc53aa3cd97f730',1,'Diccionario']]]
];
