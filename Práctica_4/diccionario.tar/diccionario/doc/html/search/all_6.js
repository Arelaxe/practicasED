var searchData=
[
  ['getdefiniciones',['GetDefiniciones',['../classTermino.html#a11d0d5aa55842b440263fc2e0d24941f',1,'Termino::GetDefiniciones()'],['../classDiccionario.html#af57dab936ac05b29da85d9939b5cfaa6',1,'Diccionario::GetDefiniciones()']]],
  ['getnumerodefiniciones',['GetNumeroDefiniciones',['../classTermino.html#ad3aac507f0f33d89abf34db00f92606f',1,'Termino']]],
  ['getnumeroterminos',['GetNumeroTerminos',['../classDiccionario.html#a52ee9ad6a4b58befe9c3603e405cb360',1,'Diccionario']]],
  ['getpalabra',['GetPalabra',['../classTermino.html#a9cff6f16a62ffa3c8c2c241a33cbd04d',1,'Termino']]],
  ['getterminos',['GetTerminos',['../classDiccionario.html#a63099f1e3380fe0ba0a69eadb89adb32',1,'Diccionario']]]
];
