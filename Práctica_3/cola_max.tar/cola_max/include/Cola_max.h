#define CUAL_COMPILA 1
#if CUAL_COMPILA == 1
 #include "Cola_max_vd.h"
#else
 #include "Cola_max_pila.h"
#endif
