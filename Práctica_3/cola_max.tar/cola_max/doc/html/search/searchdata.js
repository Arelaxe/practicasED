var indexSectionsWithContent =
{
  0: "acdefmnpqrsv",
  1: "cp",
  2: "c",
  3: "acfmnpqv",
  4: "dems",
  5: "r"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "pages"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Clases",
  2: "Archivos",
  3: "Funciones",
  4: "Variables",
  5: "Páginas"
};

