var searchData=
[
  ['pareja',['Pareja',['../structPareja.html',1,'']]],
  ['poner',['poner',['../classCola__max.html#aaba30a35b89d26659408198baccee5aa',1,'Cola_max::poner(T elemento)'],['../classCola__max.html#aaba30a35b89d26659408198baccee5aa',1,'Cola_max::poner(T elemento)']]]
];
