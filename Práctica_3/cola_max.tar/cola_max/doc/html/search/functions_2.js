var searchData=
[
  ['frente',['frente',['../classCola__max.html#a231de7f196376d7f27905b235a45db98',1,'Cola_max::frente()'],['../classCola__max.html#a810ac166b15dbd5019109aaf144705e9',1,'Cola_max::frente()']]]
];
