var searchData=
[
  ['max',['max',['../structPareja.html#a96221751f41f7524fba3e22e963e3e4f',1,'Pareja']]]
];
