var searchData=
[
  ['actualizar_5fmaximo',['actualizar_maximo',['../classCola__max.html#a3da0159f810815fbbd7f3ba895f65e62',1,'Cola_max::actualizar_maximo(T nuevo_maximo)'],['../classCola__max.html#a3da0159f810815fbbd7f3ba895f65e62',1,'Cola_max::actualizar_maximo(T nuevo_maximo)']]]
];
