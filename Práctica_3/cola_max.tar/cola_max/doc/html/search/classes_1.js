var searchData=
[
  ['pareja',['Pareja',['../structPareja.html',1,'']]]
];
