var searchData=
[
  ['dato',['dato',['../structPareja.html#a92ba8ec3cc72ad6a062e0bc29dc7b01a',1,'Pareja']]],
  ['datos',['datos',['../classCola__max.html#ada37415a95bf9e23e54aa10b478270cf',1,'Cola_max']]]
];
